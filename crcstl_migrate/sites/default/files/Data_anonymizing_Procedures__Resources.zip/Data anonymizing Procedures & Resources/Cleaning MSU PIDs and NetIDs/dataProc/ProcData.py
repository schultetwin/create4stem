#1:assumes that the file start with the content
#2:assumes that the file exist in the current directory


i = 1
while(True):
    print "Please indicate the processing needs to be done (enter 1, 2, 3 or Q):\n"
    print "1: I want to capitalize \"a\" in PIDs\n Example: a00000000 -> A00000000.\n" 
    print "2: I want to remove the email info. from Login Name to get student IDs\n Example: mikemike@msu.edu -> mikemike.\n"
    print "3: I want to remove spaces in usernames\n Example:   mikemkie   -> mikemkie.\n"
    print "Q: quit the processing program\n"
    
    
    choice = raw_input();
    if ('Q' == choice):
        exit();
    elif ("1" == choice or "2" == choice or "3" == choice):
        print "Make sure the input file is in the current directory."
        print "Please type in the input file name:"
        fileName = raw_input();
        print "The input file name is:", fileName
        print "The output file name will be: resultFile.txt"
        break;
    else:
        print "\n ****Invalid choice. Please choose again.*****\n"
        raw_input()

print "\nSummary: "
print "input file is:", fileName
print "output file is: resultFile.txt."
print "Note! existing \"resultFile.txt\" will be overwritten!"
print "Press any key to continue..."
raw_input()


try:
    inFile=open(fileName,'r')
except IOError:
    print "Can not open file ", fileName

outFile = open('resultFile.txt','w')
line_counter = 0
id_counter = 0
if ('1' == choice):
    for line in inFile:
        content = line.strip()
        print content.upper();
        outFile.write(content.upper()+'\n')
        line_counter = line_counter + 1
        if (len(content)>0):
            id_counter = id_counter +1

if ('2' == choice):
    for line in inFile:
        content = line.strip()
        li = content.partition('@')
        content = li[0]
        print content
        outFile.write(content+'\n')
        #raw_input();
        line_counter = line_counter + 1
        if (len(content)>0):
            id_counter = id_counter +1

if ('3' == choice):
    for line in inFile:
        content = line.strip()
        print content
        outFile.write(content+'\n')
        line_counter = line_counter + 1
        if (len(content)>0):
            id_counter = id_counter +1

inFile.close()
outFile.close()

print '\n'
print line_counter,  'lines Processed\n'
print id_counter,  'ids Processed\n'
