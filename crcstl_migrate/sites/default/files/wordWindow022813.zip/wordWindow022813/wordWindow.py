import sys
import math
import string
#print sys.argv
if len(sys.argv) != 4:  # the program name and the two arguments
  # stop the program and print an error message
  sys.exit("Must provide two words")
  
word_1 = (sys.argv[1]).lower()
word_2 = (sys.argv[2]).lower()
dist = int((sys.argv[3]).lower())

print "Two key words are: %s, %s" % (word_1, word_2)
print "The window size is: %d" % (dist)
print "press any key to continue..."
#open('newText.txt', 'w').write(text)


in_file = open("text.txt",'r')
#in_file = open("first420.txt",'r')
#in_file = open("WorkbookTabWindows.txt",'r')
#in_file = open("Q5wordwindowdata.txt",'r')
out_file_name = sys.argv[1] + "_" + sys.argv[2] + "_" + sys.argv[3] + ".txt"
print out_file_name
out_file = open(out_file_name, 'w')
#out_file = open("AllResults.txt", 'w')
#out_file = open("YesNo420.txt", 'w')

raw_input()
lineString = in_file.read();
#print lineString
#for line in lines1:
#  print line
#  raw_input()
#raw_input()
lines = lineString.split('\n');

print len(lines);
#for line in lines:
#  if ((len(line)>2) and (line.find("Dear")!=-1)):
    #print line
    #raw_input()

#lines = in_file.readlines()#.split('\r')
#print lines
#li = lines.split("\r")
#for line in lie:
#  print line
#  raw_input()

print "split done..."
raw_input()

#for line in in_file:
counter = 1
for line in lines:
  line = line.translate(None, string.punctuation)
  li = line.strip()
  li = line.split()
  if len(li)>0:
      #raw_input()
    #print li
    li = [x.lower() for x in li]
    #print li
    pos_1 = [i for i,x in enumerate(li) if x == word_1]
    pos_2 = [i for i,x in enumerate(li) if x == word_2]
    #print pos_1
    #print pos_2
    #print dist
    
    #raw_input()
    YesOrNo = 0
    for i in pos_1:
      for j in pos_2:
        oneDist = abs(i-j)
        #print oneDist
            #print dist
        if (oneDist<dist):
          YesOrNo = 1
                #print
                #print YesOrNo
                #print
    out_file.write(str(counter)+": "+str(YesOrNo)+'\n')
    counter = counter+1
    #raw_input()
